export enum Country {
    Russia = 'Russia',
    Belarus = 'Belarus',
    Ukraine = 'Ukraine',
    Kazakhstan = 'Kazahstan',
    Armenia = 'Armenia',
}
